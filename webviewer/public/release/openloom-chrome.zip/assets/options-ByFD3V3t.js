import{c as t,j as o,A as e}from"./index-Ce-_EV5P.js";import"./idb-D6-hFbxX.js";import"./index-R2TvDJ56.js";t.createRoot(document.getElementById("root")).render(o.jsx(e,{}));
