var We=Object.defineProperty;var Xe=(e,t,o)=>t in e?We(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var xe=(e,t,o)=>Xe(e,typeof t!="symbol"?t+"":t,o);import{v as Ke,i as Ye,f as Qe,d as Ze,g as et,a as tt,b as De,c as ot,e as nt}from"./assets/index-R2TvDJ56.js";import{getBlob as rt,deleteBlob as st}from"./assets/idb-D6-hFbxX.js";const Ue="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";function at(e=8){let t="";const o=new Uint8Array(e);crypto.getRandomValues(o);for(let n=0;n<e;n++)t+=Ue[o[n]%Ue.length];return t}async function it(e){for(let t=0;t<10;t++){const o=at();if(!await e(o))return o}throw new Error("Failed to generate unique short code after 10 attempts")}const ct=1e5;function Ie(e){const t=new Uint8Array(e);let o="";for(let n=0;n<t.length;n++)o+=String.fromCharCode(t[n]);return btoa(o)}async function ut(e,t){const o=new TextEncoder,n=await crypto.subtle.importKey("raw",o.encode(e),"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t,iterations:ct,hash:"SHA-256"},n,{name:"AES-GCM",length:256},!1,["encrypt"])}async function lt(e,t){const o=crypto.getRandomValues(new Uint8Array(16)),n=crypto.getRandomValues(new Uint8Array(12)),r=await ut(t,o),s=new TextEncoder,a=await crypto.subtle.encrypt({name:"AES-GCM",iv:n},r,s.encode(e)),c=new Uint8Array(n.length+new Uint8Array(a).length);return c.set(n),c.set(new Uint8Array(a),n.length),{encrypted:Ie(c.buffer),salt:Ie(o.buffer)}}var j=Uint8Array,L=Uint16Array,Ee=Int32Array,be=new j([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Se=new j([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Pe=new j([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Be=function(e,t){for(var o=new L(31),n=0;n<31;++n)o[n]=t+=1<<e[n-1];for(var r=new Ee(o[30]),n=1;n<30;++n)for(var s=o[n];s<o[n+1];++s)r[s]=s-o[n]<<5|n;return{b:o,r}},qe=Be(be,2),dt=qe.b,pe=qe.r;dt[28]=258,pe[258]=28;var ft=Be(Se,0),Le=ft.r,he=new L(32768);for(var A=0;A<32768;++A){var z=(A&43690)>>1|(A&21845)<<1;z=(z&52428)>>2|(z&13107)<<2,z=(z&61680)>>4|(z&3855)<<4,he[A]=((z&65280)>>8|(z&255)<<8)>>1}var se=(function(e,t,o){for(var n=e.length,r=0,s=new L(t);r<n;++r)e[r]&&++s[e[r]-1];var a=new L(t);for(r=1;r<t;++r)a[r]=a[r-1]+s[r-1]<<1;var c;if(o){c=new L(1<<t);var u=15-t;for(r=0;r<n;++r)if(e[r])for(var d=r<<4|e[r],i=t-e[r],f=a[e[r]-1]++<<i,g=f|(1<<i)-1;f<=g;++f)c[he[f]>>u]=d}else for(c=new L(n),r=0;r<n;++r)e[r]&&(c[r]=he[a[e[r]-1]++]>>15-e[r]);return c}),W=new j(288);for(var A=0;A<144;++A)W[A]=8;for(var A=144;A<256;++A)W[A]=9;for(var A=256;A<280;++A)W[A]=7;for(var A=280;A<288;++A)W[A]=8;var ae=new j(32);for(var A=0;A<32;++A)ae[A]=5;var pt=se(W,9,0),ht=se(ae,5,0),He=function(e){return(e+7)/8|0},gt=function(e,t,o){return(o==null||o>e.length)&&(o=e.length),new j(e.subarray(t,o))},G=function(e,t,o){o<<=t&7;var n=t/8|0;e[n]|=o,e[n+1]|=o>>8},oe=function(e,t,o){o<<=t&7;var n=t/8|0;e[n]|=o,e[n+1]|=o>>8,e[n+2]|=o>>16},fe=function(e,t){for(var o=[],n=0;n<e.length;++n)e[n]&&o.push({s:n,f:e[n]});var r=o.length,s=o.slice();if(!r)return{t:Ve,l:0};if(r==1){var a=new j(o[0].s+1);return a[o[0].s]=1,{t:a,l:1}}o.sort(function(N,T){return N.f-T.f}),o.push({s:-1,f:25001});var c=o[0],u=o[1],d=0,i=1,f=2;for(o[0]={s:-1,f:c.f+u.f,l:c,r:u};i!=r-1;)c=o[o[d].f<o[f].f?d++:f++],u=o[d!=i&&o[d].f<o[f].f?d++:f++],o[i++]={s:-1,f:c.f+u.f,l:c,r:u};for(var g=s[0].s,n=1;n<r;++n)s[n].s>g&&(g=s[n].s);var h=new L(g+1),v=ge(o[i-1],h,0);if(v>t){var n=0,w=0,b=v-t,y=1<<b;for(s.sort(function(T,O){return h[O.s]-h[T.s]||T.f-O.f});n<r;++n){var E=s[n].s;if(h[E]>t)w+=y-(1<<v-h[E]),h[E]=t;else break}for(w>>=b;w>0;){var C=s[n].s;h[C]<t?w-=1<<t-h[C]++-1:++n}for(;n>=0&&w;--n){var S=s[n].s;h[S]==t&&(--h[S],++w)}v=t}return{t:new j(h),l:v}},ge=function(e,t,o){return e.s==-1?Math.max(ge(e.l,t,o+1),ge(e.r,t,o+1)):t[e.s]=o},Fe=function(e){for(var t=e.length;t&&!e[--t];);for(var o=new L(++t),n=0,r=e[0],s=1,a=function(u){o[n++]=u},c=1;c<=t;++c)if(e[c]==r&&c!=t)++s;else{if(!r&&s>2){for(;s>138;s-=138)a(32754);s>2&&(a(s>10?s-11<<5|28690:s-3<<5|12305),s=0)}else if(s>3){for(a(r),--s;s>6;s-=6)a(8304);s>2&&(a(s-3<<5|8208),s=0)}for(;s--;)a(r);s=1,r=e[c]}return{c:o.subarray(0,n),n:t}},ne=function(e,t){for(var o=0,n=0;n<t.length;++n)o+=e[n]*t[n];return o},Ge=function(e,t,o){var n=o.length,r=He(t+2);e[r]=n&255,e[r+1]=n>>8,e[r+2]=e[r]^255,e[r+3]=e[r+1]^255;for(var s=0;s<n;++s)e[r+s+4]=o[s];return(r+4+n)*8},ke=function(e,t,o,n,r,s,a,c,u,d,i){G(t,i++,o),++r[256];for(var f=fe(r,15),g=f.t,h=f.l,v=fe(s,15),w=v.t,b=v.l,y=Fe(g),E=y.c,C=y.n,S=Fe(w),N=S.c,T=S.n,O=new L(19),p=0;p<E.length;++p)++O[E[p]&31];for(var p=0;p<N.length;++p)++O[N[p]&31];for(var m=fe(O,7),I=m.t,X=m.l,P=19;P>4&&!I[Pe[P-1]];--P);var K=d+5<<3,F=ne(r,W)+ne(s,ae)+a,k=ne(r,g)+ne(s,w)+a+14+3*P+ne(O,I)+2*O[16]+3*O[17]+7*O[18];if(u>=0&&K<=F&&K<=k)return Ge(t,i,e.subarray(u,u+d));var B,x,M,J;if(G(t,i,1+(k<F)),i+=2,k<F){B=se(g,h,0),x=g,M=se(w,b,0),J=w;var ce=se(I,X,0);G(t,i,C-257),G(t,i+5,T-1),G(t,i+10,P-4),i+=14;for(var p=0;p<P;++p)G(t,i+3*p,I[Pe[p]]);i+=3*P;for(var q=[E,N],te=0;te<2;++te)for(var Y=q[te],p=0;p<Y.length;++p){var H=Y[p]&31;G(t,i,ce[H]),i+=I[H],H>15&&(G(t,i,Y[p]>>5&127),i+=Y[p]>>12)}}else B=pt,x=W,M=ht,J=ae;for(var p=0;p<c;++p){var D=n[p];if(D>255){var H=D>>18&31;oe(t,i,B[H+257]),i+=x[H+257],H>7&&(G(t,i,D>>23&31),i+=be[H]);var Q=D&31;oe(t,i,M[Q]),i+=J[Q],Q>3&&(oe(t,i,D>>5&8191),i+=Se[Q])}else oe(t,i,B[D]),i+=x[D]}return oe(t,i,B[256]),i+x[256]},mt=new Ee([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),Ve=new j(0),vt=function(e,t,o,n,r,s){var a=s.z||e.length,c=new j(n+a+5*(1+Math.ceil(a/7e3))+r),u=c.subarray(n,c.length-r),d=s.l,i=(s.r||0)&7;if(t){i&&(u[0]=s.r>>3);for(var f=mt[t-1],g=f>>13,h=f&8191,v=(1<<o)-1,w=s.p||new L(32768),b=s.h||new L(v+1),y=Math.ceil(o/3),E=2*y,C=function(de){return(e[de]^e[de+1]<<y^e[de+2]<<E)&v},S=new Ee(25e3),N=new L(288),T=new L(32),O=0,p=0,m=s.i||0,I=0,X=s.w||0,P=0;m+2<a;++m){var K=C(m),F=m&32767,k=b[K];if(w[F]=k,b[K]=F,X<=m){var B=a-m;if((O>7e3||I>24576)&&(B>423||!d)){i=ke(e,u,0,S,N,T,p,I,P,m-P,i),I=O=p=0,P=m;for(var x=0;x<286;++x)N[x]=0;for(var x=0;x<30;++x)T[x]=0}var M=2,J=0,ce=h,q=F-k&32767;if(B>2&&K==C(m-q))for(var te=Math.min(g,B)-1,Y=Math.min(32767,m),H=Math.min(258,B);q<=Y&&--ce&&F!=k;){if(e[m+M]==e[m+M-q]){for(var D=0;D<H&&e[m+D]==e[m+D-q];++D);if(D>M){if(M=D,J=q,D>te)break;for(var Q=Math.min(q,D-2),Oe=0,x=0;x<Q;++x){var ue=m-q+x&32767,ze=w[ue],$e=ue-ze&32767;$e>Oe&&(Oe=$e,k=ue)}}}F=k,k=w[F],q+=F-k&32767}if(J){S[I++]=268435456|pe[M]<<18|Le[J];var Ne=pe[M]&31,Re=Le[J]&31;p+=be[Ne]+Se[Re],++N[257+Ne],++T[Re],X=m+M,++O}else S[I++]=e[m],++N[e[m]]}}for(m=Math.max(m,X);m<a;++m)S[I++]=e[m],++N[e[m]];i=ke(e,u,d,S,N,T,p,I,P,m-P,i),d||(s.r=i&7|u[i/8|0]<<3,i-=7,s.h=b,s.p=w,s.i=m,s.w=X)}else{for(var m=s.w||0;m<a+d;m+=65535){var le=m+65535;le>=a&&(u[i/8|0]=d,le=a),i=Ge(u,i+1,e.subarray(m,le))}s.i=a}return gt(c,0,n+He(i)+r)},wt=function(e,t,o,n,r){if(!r&&(r={l:1},t.dictionary)){var s=t.dictionary.subarray(-32768),a=new j(s.length+e.length);a.set(s),a.set(e,s.length),e=a,r.w=s.length}return vt(e,t.level==null?6:t.level,t.mem==null?r.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,o,n,r)};function yt(e,t){return wt(e,{},0,0)}var Et=typeof TextDecoder<"u"&&new TextDecoder,bt=0;try{Et.decode(Ve,{stream:!0}),bt=1}catch{}function St(e){let t=4294967295;for(let o=0;o<e.length;o++){t^=e[o];for(let n=0;n<8;n++)t=t&1?t>>>1^3988292384:t>>>1}return(t^4294967295)>>>0}function Tt(e){const t=(e.getHours()&31)<<11|(e.getMinutes()&63)<<5|e.getSeconds()>>1&31,o=(e.getFullYear()-1980&127)<<9|(e.getMonth()+1&15)<<5|e.getDate()&31;return{time:t,dateVal:o}}function _t(e){const t=new Date,{time:o,dateVal:n}=Tt(t),r=[],s=[];let a=0;const c=new TextEncoder;for(const b of e){const y=c.encode(b.name),E=b.content,C=yt(E),S=St(E),N=new Uint8Array(30),T=new DataView(N.buffer);T.setUint32(0,67324752,!0),T.setUint16(4,20,!0),T.setUint16(6,0,!0),T.setUint16(8,8,!0),T.setUint16(10,o,!0),T.setUint16(12,n,!0),T.setUint32(14,S,!0),T.setUint32(18,C.length,!0),T.setUint32(22,E.length,!0),T.setUint16(26,y.length,!0),T.setUint16(28,0,!0),r.push(N,y,C);const O=new Uint8Array(46),p=new DataView(O.buffer);p.setUint32(0,33639248,!0),p.setUint16(4,20,!0),p.setUint16(6,20,!0),p.setUint16(8,0,!0),p.setUint16(10,8,!0),p.setUint16(12,o,!0),p.setUint16(14,n,!0),p.setUint32(16,S,!0),p.setUint32(20,C.length,!0),p.setUint32(24,E.length,!0),p.setUint16(28,y.length,!0),p.setUint16(30,0,!0),p.setUint16(32,0,!0),p.setUint16(34,0,!0),p.setUint16(36,0,!0),p.setUint32(38,0,!0),p.setUint32(42,a,!0),s.push(O,y),a+=N.length+y.length+C.length}const u=a;let d=0;for(const b of s)d+=b.length;const i=new Uint8Array(22),f=new DataView(i.buffer);f.setUint32(0,101010256,!0),f.setUint16(4,0,!0),f.setUint16(6,0,!0),f.setUint16(8,e.length,!0),f.setUint16(10,e.length,!0),f.setUint32(12,d,!0),f.setUint32(16,u,!0),f.setUint16(20,0,!0);const g=[...r,...s,i],h=g.reduce((b,y)=>b+y.length,0),v=new Uint8Array(h);let w=0;for(const b of g)v.set(b,w),w+=b.length;return v}const At=`
const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

const DB_ID = process.env.FIRESTORE_DB_ID || "(default)";
function getDb() {
  if (DB_ID && DB_ID !== "(default)") {
    return admin.firestore().databaseId === DB_ID
      ? admin.firestore()
      : require("firebase-admin/firestore").getFirestore(admin.app(), DB_ID);
  }
  return admin.firestore();
}

function json(res, data, status) {
  status = status || 200;
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type");
  res.status(status).json(data);
}

exports.openloom = functions.https.onRequest(function (req, res) {
  if (req.method === "OPTIONS") {
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type");
    res.status(204).send("");
    return;
  }

  var db = getDb();
  var path = req.path;

  // GET /v/:code
  var videoMatch = path.match(/^\\/v\\/([\\w-]+)$/);
  if (videoMatch && req.method === "GET") {
    var code = videoMatch[1];
    return db.collection("videos").doc(code).get().then(function (doc) {
      if (!doc.exists) return json(res, { error: "Video not found" }, 404);
      json(res, doc.data());
    }).catch(function (e) { json(res, { error: e.message }, 500); });
  }

  // POST /v/:code/view
  var viewMatch = path.match(/^\\/v\\/([\\w-]+)\\/view$/);
  if (viewMatch && req.method === "POST") {
    var code2 = viewMatch[1];
    var ref = db.collection("videos").doc(code2);
    return ref.get().then(function (doc) {
      if (!doc.exists) return json(res, { error: "Video not found" }, 404);
      return ref.update({ view_count: admin.firestore.FieldValue.increment(1) })
        .then(function () { json(res, { ok: true }); });
    }).catch(function (e) { json(res, { error: e.message }, 500); });
  }

  // GET /v/:code/reactions
  var reactionsMatch = path.match(/^\\/v\\/([\\w-]+)\\/reactions$/);
  if (reactionsMatch && req.method === "GET") {
    var code3 = reactionsMatch[1];
    return db.collection("videos").doc(code3).collection("reactions")
      .orderBy("created_at", "asc").get()
      .then(function (snapshot) {
        var reactions = snapshot.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
        json(res, reactions);
      }).catch(function (e) { json(res, { error: e.message }, 500); });
  }

  // POST /v/:code/reactions
  if (reactionsMatch && req.method === "POST") {
    var code4 = reactionsMatch[1];
    var body = req.body || {};
    if (!body.emoji || typeof body.timestamp !== "number") {
      return json(res, { error: "emoji and timestamp are required" }, 400);
    }
    return db.collection("videos").doc(code4).collection("reactions")
      .add({ emoji: body.emoji, timestamp: body.timestamp, created_at: admin.firestore.FieldValue.serverTimestamp() })
      .then(function (docRef) {
        return docRef.get().then(function (created) {
          json(res, Object.assign({ id: docRef.id }, created.data()), 201);
        });
      }).catch(function (e) { json(res, { error: e.message }, 500); });
  }

  json(res, { error: "Not found" }, 404);
});
`.trim(),Ct=JSON.stringify({name:"openloom-cloud-function",version:"1.0.0",private:!0,main:"index.js",engines:{node:"20"},dependencies:{"firebase-admin":"^12.0.0","firebase-functions":"^4.9.0"}},null,2);function l(e,t){const o=new Date().toISOString();t!==void 0?console.log(`[deploy-cf ${o}] ${e}`,t):console.log(`[deploy-cf ${o}] ${e}`)}function Ot(e){let t="";for(let o=0;o<e.length;o++)t+=String.fromCharCode(e[o]);return btoa(t).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}function Me(e){return btoa(e).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}function $t(e){const t=e.replace(/-----BEGIN [\w\s]+-----/,"").replace(/-----END [\w\s]+-----/,"").replace(/\s/g,""),o=atob(t),n=new Uint8Array(o.length);for(let r=0;r<o.length;r++)n[r]=o.charCodeAt(r);return n.buffer}async function Nt(e){const t=JSON.parse(e);l(`Getting access token for SA: ${t.client_email}, project: ${t.project_id}`);const o=Math.floor(Date.now()/1e3),n={alg:"RS256",typ:"JWT"},r={iss:t.client_email,scope:"https://www.googleapis.com/auth/cloud-platform",aud:"https://oauth2.googleapis.com/token",iat:o,exp:o+3600},s=Me(JSON.stringify(n)),a=Me(JSON.stringify(r)),c=`${s}.${a}`,u=$t(t.private_key),d=await crypto.subtle.importKey("pkcs8",u,{name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"},!1,["sign"]),i=await crypto.subtle.sign("RSASSA-PKCS1-v1_5",d,new TextEncoder().encode(c)),f=Ot(new Uint8Array(i)),g=`${c}.${f}`,h=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${g}`});if(!h.ok){const w=await h.text();throw new Error(`Failed to get access token: ${h.status} ${w}`)}const v=await h.json();return l(`Access token obtained (${v.access_token.substring(0,20)}...)`),v.access_token}class Z extends Error{constructor(o,n){super(o);xe(this,"enableUrls");this.enableUrls=n}}const Te=[{name:"cloudfunctions.googleapis.com",label:"Cloud Functions API",slug:"cloudfunctions.googleapis.com"},{name:"cloudbuild.googleapis.com",label:"Cloud Build API",slug:"cloudbuild.googleapis.com"},{name:"artifactregistry.googleapis.com",label:"Artifact Registry API",slug:"artifactregistry.googleapis.com"},{name:"run.googleapis.com",label:"Cloud Run Admin API",slug:"run.googleapis.com"}];async function Rt(e,t){const o=`https://cloudresourcemanager.googleapis.com/v1/projects/${t}`;l(`Resolving project number for: ${t}`);const n=await fetch(o,{headers:{Authorization:`Bearer ${e}`}});if(!n.ok){const s=await n.text();return l(`Failed to resolve project number: ${n.status} ${n.statusText}`,s),t}const r=await n.json();return l(`Project number resolved: ${r.projectNumber}`),r.projectNumber||t}async function je(e,t,o){const n=`https://serviceusage.googleapis.com/v1/projects/${t}/services/${o}:enable`;l(`Enabling API: ${o} via ${n}`);const r=await fetch(n,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({})});if(!r.ok){const a=await r.text();return l(`Enable API ${o} failed: ${r.status} ${r.statusText}`,a),{ok:!1,status:r.status,error:a}}const s=await r.json();return l(`Enable API ${o} succeeded`,s),{ok:!0,status:r.status}}async function me(e,t){const o=[];for(const n of Te)try{const r=`https://serviceusage.googleapis.com/v1/projects/${t}/services/${n.name}`,s=await fetch(r,{headers:{Authorization:`Bearer ${e}`}});s.ok?(await s.json()).state!=="ENABLED"&&o.push({label:`Enable ${n.label}`,url:`https://console.cloud.google.com/apis/library/${n.slug}?project=${t}`}):o.push({label:`Enable ${n.label}`,url:`https://console.cloud.google.com/apis/library/${n.slug}?project=${t}`})}catch{o.push({label:`Enable ${n.label}`,url:`https://console.cloud.google.com/apis/library/${n.slug}?project=${t}`})}return o}function ve(e){return new Z("Required APIs are not enabled. Please enable them in the GCP Console, then retry.",e)}function we(e){return new Z("Required APIs are not enabled. Please enable them in the GCP Console, then retry.",Te.map(t=>({label:`Enable ${t.label}`,url:`https://console.cloud.google.com/apis/library/${t.slug}?project=${e}`})))}function xt(e,t){return new Z(`The service account ${t} is missing required IAM roles. Grant "Cloud Functions Developer", "Service Account User", and "Cloud Run Admin", then retry.`,[{label:"Open IAM Settings",url:`https://console.cloud.google.com/iam-admin/iam?project=${e}`}])}async function Dt(e,t){const o=await Rt(e,t);l(`Using project identifier for Service Usage: ${o} (original: ${t})`);for(const n of Te.map(r=>r.name)){let r=await je(e,o,n);!r.ok&&o!==t&&(r=await je(e,t,n)),r.ok?l(`Successfully enabled ${n}`):l(`Could not enable ${n} (SA lacks permission) -- will attempt deployment anyway`)}}async function Ut(e,t,o){const n=`https://cloudfunctions.googleapis.com/v2/projects/${t}/locations/us-central1/functions`;l(`Checking Cloud Functions v2 access: ${n}`);const r=await fetch(n,{headers:{Authorization:`Bearer ${e}`}}),s=await r.text();if(l(`Cloud Functions v2 access check: ${r.status}`,s.substring(0,500)),r.ok)return;if(s.toLowerCase().includes("<!doctype")||s.toLowerCase().includes("<html")){l("HTML response -- API not enabled, checking which APIs are disabled...");const c=await me(e,t);throw c.length>0?ve(c):we(t)}if(r.status===403){const c=s.toLowerCase();if(c.includes("has not been used")||c.includes("is disabled")){l("API not enabled (JSON 403), checking which APIs are disabled...");const u=await me(e,t);throw u.length>0?ve(u):we(t)}throw l("API enabled but SA lacks Cloud Functions permissions"),xt(t,o)}}async function It(e,t,o){const n=`cloud-function-source/openloom-${Date.now()}.zip`,r=`https://storage.googleapis.com/upload/storage/v1/b/${encodeURIComponent(t)}/o?uploadType=media&name=${encodeURIComponent(n)}`;l(`Uploading source to GCS: gs://${t}/${n} (${o.length} bytes)`);const s=await fetch(r,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/zip"},body:o});if(!s.ok){const a=await s.text();throw l(`GCS upload failed: ${s.status}`,a),new Error(`Failed to upload source to GCS: ${s.statusText}`)}return l(`Source uploaded to gs://${t}/${n}`),{bucket:t,object:n}}async function Pt(e,t){const o=`https://cloudfunctions.googleapis.com/v2/${t}`;l(`Checking if v2 function exists: ${o}`);const n=await fetch(o,{headers:{Authorization:`Bearer ${e}`}});if(n.ok){const a=await n.json();return l(`Function found via v2 API, environment: ${a.environment}`),a.environment==="GEN_1"?"v1":"v2"}const r=`https://cloudfunctions.googleapis.com/v1/${t}`;return l(`Checking if v1 function exists: ${r}`),(await fetch(r,{headers:{Authorization:`Bearer ${e}`}})).ok?(l("Function exists as v1 (1st gen)"),"v1"):(l("Function does not exist"),"none")}async function Lt(e,t){const o=`https://cloudfunctions.googleapis.com/v1/${t}`;l(`Deleting v1 function: ${o}`);const n=await fetch(o,{method:"DELETE",headers:{Authorization:`Bearer ${e}`}});if(!n.ok){const a=await n.text();throw l(`Delete v1 function failed: ${n.status}`,a),new Error(`Failed to delete existing v1 function: ${n.status}`)}const r=await n.json();l(`Delete operation started: ${r.name}`);const s=Date.now();for(;Date.now()-s<12e4;){await new Promise(c=>setTimeout(c,5e3));const a=await fetch(`https://cloudfunctions.googleapis.com/v1/${r.name}`,{headers:{Authorization:`Bearer ${e}`}});if(a.ok){const c=await a.json();if(c.error)throw new Error(`Delete v1 function failed: ${c.error.message}`);if(c.done){l("V1 function deleted successfully");return}}}throw new Error("Timed out waiting for v1 function deletion")}async function Ft(e,t,o,n){var g,h,v,w;const r=`projects/${t}/locations/us-central1`,s=`${r}/functions/openloom`,a=await Pt(e,s);a==="v1"&&(l("Existing v1 function detected -- deleting before creating v2..."),await Lt(e,s));const c={name:s,buildConfig:{runtime:"nodejs20",entryPoint:"openloom",source:{storageSource:{bucket:o.bucket,object:o.object}}},serviceConfig:{availableMemory:"256Mi",timeoutSeconds:60,environmentVariables:{FIRESTORE_DB_ID:n||"(default)"},ingressSettings:"ALLOW_ALL",allTrafficOnLatestRevision:!0}};let u,d;a==="v2"?(u=`https://cloudfunctions.googleapis.com/v2/${s}?updateMask=buildConfig,serviceConfig`,d="PATCH",l(`Updating existing v2 function: ${d} ${u}`)):(u=`https://cloudfunctions.googleapis.com/v2/${r}/functions?functionId=openloom`,d="POST",l(`Creating new v2 function: ${d} ${u}`)),l("Function payload:",c);const i=await fetch(u,{method:d,headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify(c)});if(!i.ok){const b=await i.text();l(`Create/update function failed: ${i.status}`,b);let y={};try{y=JSON.parse(b)}catch{}if(a!=="v2"&&((g=y.error)==null?void 0:g.code)===409){l("Function already exists (409), falling back to PATCH");const C=`https://cloudfunctions.googleapis.com/v2/${s}?updateMask=buildConfig,serviceConfig`,S=await fetch(C,{method:"PATCH",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify(c)});if(!S.ok){const T=await S.text();l(`Fallback PATCH failed: ${S.status}`,T);let O={};try{O=JSON.parse(T)}catch{}throw new Error(((h=O.error)==null?void 0:h.message)||S.statusText)}const N=await S.json();return l(`Fallback PATCH succeeded, operation: ${N.name}`),N.name}const E=((v=y.error)==null?void 0:v.message)||"";if(E.includes("iam.serviceaccounts.actAs")){const C=E.match(/serviceAccounts\/([\w.@-]+)/),S=(C==null?void 0:C[1])||"the default compute service account";throw new Z(`Grant the "Service Account User" role to your service account on ${S}, then retry.`,[{label:"Open IAM Settings",url:`https://console.cloud.google.com/iam-admin/iam?project=${t}`}])}if(E.includes("has not been used")||E.includes("is disabled")){const C=await me(e,t);throw C.length>0?ve(C):we(t)}throw new Error(((w=y.error)==null?void 0:w.message)||i.statusText)}const f=await i.json();return l(`Function ${a==="v2"?"update":"create"} succeeded, operation: ${f.name}`),f.name}async function kt(e,t,o=6e5){var a,c,u;const n=Date.now(),r=5e3;let s=0;for(l(`Polling operation (v2): ${t} (timeout: ${o}ms)`);Date.now()-n<o;){await new Promise(i=>setTimeout(i,r)),s++;const d=await fetch(`https://cloudfunctions.googleapis.com/v2/${t}`,{headers:{Authorization:`Bearer ${e}`}});if(d.ok){const i=await d.json();if(l(`Poll #${s}: done=${i.done}`,i.error||i.metadata||""),i.error)throw new Error(`Deployment failed: ${i.error.message}`);if(i.done){l(`Operation completed after ${s} polls (${Math.round((Date.now()-n)/1e3)}s)`);const f=((a=i.response)==null?void 0:a.url)||((u=(c=i.response)==null?void 0:c.serviceConfig)==null?void 0:u.uri);return f&&l(`Function URL: ${f}`),f}}else l(`Poll #${s}: HTTP ${d.status}`)}throw new Error("Deployment timed out -- the function may still be deploying in the GCP console. Wait a minute, then try again.")}async function Mt(e,t){var a;const o=`https://cloudfunctions.googleapis.com/v2/${t}`;l(`Fetching function details for URL: ${o}`);const n=await fetch(o,{headers:{Authorization:`Bearer ${e}`}});if(!n.ok){l(`Failed to fetch function: ${n.status}`);return}const r=await n.json(),s=r.url||((a=r.serviceConfig)==null?void 0:a.uri);return l(`Function URL from GET: ${s}`),s}async function jt(e,t,o){var d;const n=`https://cloudfunctions.googleapis.com/v2/${o}`;l(`Fetching function details for Cloud Run service: ${n}`);const r=await fetch(n,{headers:{Authorization:`Bearer ${e}`}});if(!r.ok)throw new Error(`Failed to get function details: ${r.status}`);let a=(d=(await r.json()).serviceConfig)==null?void 0:d.service;if(l(`Cloud Run service from function: ${a}`),!a)throw new Error("Could not determine Cloud Run service name from function");a.startsWith("projects/")||(a=`projects/${t}/locations/us-central1/services/${a}`,l(`Expanded service name: ${a}`));const c=`https://run.googleapis.com/v2/${a}:setIamPolicy`;l(`Setting public access on Cloud Run service: ${c}`);const u=await fetch(c,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({policy:{bindings:[{role:"roles/run.invoker",members:["allUsers"]}]}})});if(!u.ok){const i=await u.text();throw l(`setIamPolicy on Cloud Run failed: ${u.status}`,i),u.status===403?new Z('The service account lacks permission to make the function publicly accessible. Grant the "Cloud Run Admin" role to the service account, then retry.',[{label:"Open IAM Settings",url:`https://console.cloud.google.com/iam-admin/iam?project=${t}`}]):new Error(`Failed to set public access: ${i}`)}l("Public access set successfully -- allUsers can invoke the function")}async function Bt(e,t){const o=e.serviceAccountJson,n=e.firebaseProjectId,r=e.firestoreDbId,s=e.resolvedBucket;if(!o||!n||!s)return t([{id:"validate",label:"Validating settings...",status:"error",error:"Missing required Firebase settings (service account, project ID, or storage bucket)."}]),!1;const c=JSON.parse(o).client_email||"unknown",u=[{id:"enable-apis",label:"Enabling required APIs...",status:"pending"},{id:"check-access",label:"Checking Cloud Functions access...",status:"pending"},{id:"upload-source",label:"Building & uploading function source...",status:"pending"},{id:"create-function",label:"Creating/updating Cloud Function...",status:"pending"},{id:"set-public-access",label:"Setting public access...",status:"pending"}];function d(i,f){const g=u.find(h=>h.id===i);g&&Object.assign(g,f),t([...u])}l("=== Starting Cloud Function deployment (v2 / 2nd gen) ==="),l(`Project: ${n}, SA: ${c}, Bucket: ${s}, Firestore DB: ${r||"(default)"}`);try{const i=await Nt(o);d("enable-apis",{status:"running"}),l("Step 1/5: Attempting to enable APIs (best-effort)..."),await Dt(i,n),d("enable-apis",{status:"done"}),l("Step 1/5: Done"),d("check-access",{status:"running"}),l("Step 2/5: Checking Cloud Functions v2 access..."),await Ut(i,n,c),d("check-access",{status:"done"}),l("Step 2/5: Cloud Functions v2 access confirmed"),d("upload-source",{status:"running"}),l("Step 3/5: Building ZIP and uploading source to GCS...");const f=new TextEncoder,g=_t([{name:"index.js",content:f.encode(At)},{name:"package.json",content:f.encode(Ct)}]);l(`ZIP built (${g.length} bytes)`);const h=await It(i,s,g);d("upload-source",{status:"done"}),l("Step 3/5: Source uploaded to GCS"),d("create-function",{status:"running"}),l("Step 4/5: Creating/updating function (v2)...");let v;for(let y=1;y<=5;y++)try{v=await Ft(i,n,h,r);break}catch(E){if((E instanceof Error?E.message:String(E)).includes("unable to queue")&&y<5)l(`Step 4/5: Attempt ${y} failed (operation in progress), retrying in 15s...`),await new Promise(S=>setTimeout(S,15e3));else throw E}if(!v)throw new Error("Failed to create/update function after retries");d("create-function",{status:"waiting",label:"Waiting for deployment to complete..."}),l("Step 4/5: Waiting for deployment to complete...");let w=await kt(i,v);d("create-function",{status:"done",label:"Creating/updating Cloud Function..."}),l("Step 4/5: Deployment complete");const b=`projects/${n}/locations/us-central1/functions/openloom`;w||(w=await Mt(i,b)),d("set-public-access",{status:"running"}),l("Step 5/5: Setting public access on Cloud Run service...");for(let y=1;y<=5;y++)try{await jt(i,n,b);break}catch(E){if((E instanceof Error?E.message:String(E)).includes("unable to queue")&&y<5)l(`Step 5/5: Attempt ${y} failed (service not ready), retrying in 15s...`),await new Promise(S=>setTimeout(S,15e3));else throw E}return d("set-public-access",{status:"done"}),l("Step 5/5: Public access configured"),l("=== Cloud Function deployment finished (v2) ==="),w&&l(`Function URL: ${w}`),!0}catch(i){if(i instanceof Z){l(`=== Cloud Function deployment BLOCKED: ${i.message} ===`);const h=u.find(v=>v.status==="running"||v.status==="waiting");return h&&d(h.id,{status:"error",error:i.message,actions:i.enableUrls}),!1}const f=i instanceof Error?i.message:String(i);l(`=== Cloud Function deployment FAILED: ${f} ===`);const g=u.find(h=>h.status==="running"||h.status==="waiting");return g&&d(g.id,{status:"error",error:f}),!1}}function $(e,t){const o=new Date().toISOString();t!==void 0?console.log(`[deploy-convex ${o}] ${e}`,t):console.log(`[deploy-convex ${o}] ${e}`)}const qt=`
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  videos: defineTable({
    short_code: v.string(),
    title: v.string(),
    description: v.optional(v.union(v.string(), v.null())),
    storage_url: v.string(),
    storage_id: v.optional(v.id("_storage")),
    view_count: v.number(),
    duration_ms: v.optional(v.union(v.number(), v.null())),
    capture_mode: v.string(),
    created_at: v.string(),
    is_protected: v.optional(v.boolean()),
    password_salt: v.optional(v.string()),
  })
    .index("by_short_code", ["short_code"])
    .index("by_created_at", ["created_at"]),

  reactions: defineTable({
    video_short_code: v.string(),
    emoji: v.string(),
    timestamp: v.number(),
    created_at: v.string(),
  }).index("by_video_short_code", ["video_short_code"]),
});
`.trim(),Ht=`
import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getByShortCode = query({
  args: { shortCode: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("videos")
      .withIndex("by_short_code", (q) => q.eq("short_code", args.shortCode))
      .first();
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("videos")
      .withIndex("by_created_at")
      .order("desc")
      .collect();
  },
});

export const insert = mutation({
  args: {
    short_code: v.string(),
    title: v.string(),
    description: v.optional(v.union(v.string(), v.null())),
    storage_url: v.string(),
    storage_id: v.optional(v.id("_storage")),
    view_count: v.number(),
    duration_ms: v.optional(v.union(v.number(), v.null())),
    capture_mode: v.string(),
    created_at: v.string(),
    is_protected: v.optional(v.boolean()),
    password_salt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("videos", args);
  },
});

export const incrementViewCount = mutation({
  args: { shortCode: v.string() },
  handler: async (ctx, args) => {
    const video = await ctx.db
      .query("videos")
      .withIndex("by_short_code", (q) => q.eq("short_code", args.shortCode))
      .first();
    if (!video) throw new Error("Video not found");
    await ctx.db.patch(video._id, { view_count: video.view_count + 1 });
  },
});

export const remove = mutation({
  args: { shortCode: v.string() },
  handler: async (ctx, args) => {
    const video = await ctx.db
      .query("videos")
      .withIndex("by_short_code", (q) => q.eq("short_code", args.shortCode))
      .first();
    if (!video) return;

    // Delete from storage if storage_id exists
    if (video.storage_id) {
      await ctx.storage.delete(video.storage_id);
    }

    // Delete all reactions for this video
    const reactions = await ctx.db
      .query("reactions")
      .withIndex("by_video_short_code", (q) =>
        q.eq("video_short_code", args.shortCode)
      )
      .collect();
    for (const reaction of reactions) {
      await ctx.db.delete(reaction._id);
    }

    // Delete the video
    await ctx.db.delete(video._id);
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
`.trim(),Gt=`
import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const listByVideo = query({
  args: { videoShortCode: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("reactions")
      .withIndex("by_video_short_code", (q) =>
        q.eq("video_short_code", args.videoShortCode)
      )
      .collect();
  },
});

export const add = mutation({
  args: {
    video_short_code: v.string(),
    emoji: v.string(),
    timestamp: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("reactions", {
      video_short_code: args.video_short_code,
      emoji: args.emoji,
      timestamp: args.timestamp,
      created_at: new Date().toISOString(),
    });
  },
});
`.trim(),Vt=`
import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";

const http = httpRouter();

// GET /v?code=xxx -- video metadata
http.route({
  path: "/v",
  method: "GET",
  handler: httpAction(async (ctx, request) => {
    const url = new URL(request.url);
    const code = url.searchParams.get("code");
    if (!code) {
      return new Response(JSON.stringify({ error: "code is required" }), {
        status: 400,
        headers: corsHeaders(),
      });
    }
    const video = await ctx.runQuery("videos:getByShortCode" as any, { shortCode: code });
    if (!video) {
      return new Response(JSON.stringify({ error: "Video not found" }), {
        status: 404,
        headers: corsHeaders(),
      });
    }
    return new Response(JSON.stringify(video), { headers: corsHeaders() });
  }),
});

// POST /view -- increment view count
http.route({
  path: "/view",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const body = await request.json();
    const code = (body as any).code;
    if (!code) {
      return new Response(JSON.stringify({ error: "code is required" }), {
        status: 400,
        headers: corsHeaders(),
      });
    }
    await ctx.runMutation("videos:incrementViewCount" as any, { shortCode: code });
    return new Response(JSON.stringify({ ok: true }), { headers: corsHeaders() });
  }),
});

// GET /reactions?code=xxx -- list reactions
http.route({
  path: "/reactions",
  method: "GET",
  handler: httpAction(async (ctx, request) => {
    const url = new URL(request.url);
    const code = url.searchParams.get("code");
    if (!code) {
      return new Response(JSON.stringify({ error: "code is required" }), {
        status: 400,
        headers: corsHeaders(),
      });
    }
    const reactions = await ctx.runQuery("reactions:listByVideo" as any, {
      videoShortCode: code,
    });
    return new Response(JSON.stringify(reactions), { headers: corsHeaders() });
  }),
});

// POST /reactions/add -- add reaction
http.route({
  path: "/reactions/add",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const body = await request.json();
    const { code, emoji, timestamp } = body as any;
    if (!code || !emoji || typeof timestamp !== "number") {
      return new Response(
        JSON.stringify({ error: "code, emoji, and timestamp are required" }),
        { status: 400, headers: corsHeaders() }
      );
    }
    await ctx.runMutation("reactions:add" as any, {
      video_short_code: code,
      emoji,
      timestamp,
    });
    return new Response(JSON.stringify({ ok: true }), {
      status: 201,
      headers: corsHeaders(),
    });
  }),
});

// GET /video -- 302 redirect to fresh signed storage URL
http.route({
  path: "/video",
  method: "GET",
  handler: httpAction(async (ctx, request) => {
    const url = new URL(request.url);
    const code = url.searchParams.get("code");
    if (!code) {
      return new Response("code is required", { status: 400 });
    }
    const video = await ctx.runQuery("videos:getByShortCode" as any, { shortCode: code });
    if (!video || !video.storage_id) {
      return new Response("Video not found", { status: 404 });
    }
    const storageUrl = await ctx.storage.getUrl(video.storage_id);
    if (!storageUrl) {
      return new Response("Storage URL not available", { status: 404 });
    }
    return new Response(null, {
      status: 302,
      headers: { Location: storageUrl, "Cache-Control": "no-cache" },
    });
  }),
});

function corsHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

// Handle CORS preflight for all routes
http.route({
  path: "/v",
  method: "OPTIONS",
  handler: httpAction(async () => {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }),
});
http.route({
  path: "/view",
  method: "OPTIONS",
  handler: httpAction(async () => {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }),
});
http.route({
  path: "/reactions",
  method: "OPTIONS",
  handler: httpAction(async () => {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }),
});
http.route({
  path: "/reactions/add",
  method: "OPTIONS",
  handler: httpAction(async () => {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }),
});
http.route({
  path: "/video",
  method: "OPTIONS",
  handler: httpAction(async () => {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }),
});

export default http;
`.trim();function Jt(e){const t=e.split("|");if(t.length<2)throw new Error("Invalid deploy key format");const o=t[0],n=o.indexOf(":");if(n<0)throw new Error('Invalid deploy key format -- expected "prod:<deployment>|<secret>"');const r=o.slice(n+1);return{deploymentName:r,deploymentUrl:`https://${r}.convex.cloud`}}function zt(){return[{path:"schema.ts",source:qt,environment:"isolate"},{path:"videos.ts",source:Ht,environment:"isolate"},{path:"reactions.ts",source:Gt,environment:"isolate"},{path:"http.ts",source:Vt,environment:"node"}]}function _e(e){return{"Content-Type":"application/json",Authorization:`Convex ${e}`,"Convex-Client":"npm-cli-0.0.0"}}async function Wt(e,t,o){const n=`${e}/api/deploy2/start_push`;$(`Starting push to ${n}`);const r=await fetch(n,{method:"POST",headers:_e(t),body:JSON.stringify({adminKey:t,dryRun:!1,functions:o.map(a=>({path:a.path,source:a.source,sourceMap:null,environment:a.environment})),nodeDependencies:{}})});if(!r.ok){const a=await r.text();throw new Error(`start_push failed: ${r.status} ${a}`)}const s=await r.json();return $("start_push response:",s),s}async function Xt(e,t,o,n=6e4){const r=`${e}/api/deploy2/wait_for_schema`;$(`Waiting for schema validation: schemaId=${o}`);const s=Date.now();for(;Date.now()-s<n;){const a=await fetch(r,{method:"POST",headers:_e(t),body:JSON.stringify({adminKey:t,schemaId:o})});if(a.ok){const u=await a.json();$("wait_for_schema response:",u);return}const c=await a.text();if(a.status===400||a.status===409){$(`Schema still validating (${a.status}), retrying in 2s...`),await new Promise(u=>setTimeout(u,2e3));continue}throw new Error(`wait_for_schema failed: ${a.status} ${c}`)}throw new Error("Timed out waiting for Convex schema validation")}async function Kt(e,t){const o=`${e}/api/deploy2/finish_push`;$(`Finishing push to ${o}`);const n=await fetch(o,{method:"POST",headers:_e(t),body:JSON.stringify({adminKey:t,dryRun:!1})});if(!n.ok){const s=await n.text();throw new Error(`finish_push failed: ${n.status} ${s}`)}const r=await n.json();$("finish_push response:",r)}async function Yt(e,t){var s;const o=e.convexDeployKey;if(!o)return t([{id:"validate",label:"Validating settings...",status:"error",error:"Missing Convex deploy key."}]),!1;const n=[{id:"verify-access",label:"Verifying Convex deployment access...",status:"pending"},{id:"push-functions",label:"Pushing schema & functions...",status:"pending"},{id:"wait-schema",label:"Validating schema...",status:"pending"},{id:"finalize",label:"Finalizing deployment...",status:"pending"}];function r(a,c){const u=n.find(d=>d.id===a);u&&Object.assign(u,c),t([...n])}$("=== Starting Convex deployment ===");try{const{deploymentName:a,deploymentUrl:c}=Jt(o),u=e.convexDeploymentUrl||c;$(`Deployment: ${a}, URL: ${u}`),r("verify-access",{status:"running"}),$("Step 1/4: Verifying Convex access...");const d=await fetch(`${u}/api/query`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Convex ${o}`},body:JSON.stringify({path:"videos:list",args:{}})});if(!d.ok&&d.status!==400){if(d.status===401||d.status===403)throw new Error("Invalid deploy key -- authentication failed");const g=await d.text();throw new Error(`Convex connection failed: ${d.status} ${g}`)}r("verify-access",{status:"done"}),$("Step 1/4: Convex access verified"),r("push-functions",{status:"running"}),$("Step 2/4: Pushing schema & function definitions...");const i=zt(),f=await Wt(u,o,i);return r("push-functions",{status:"done"}),$("Step 2/4: Push started successfully"),r("wait-schema",{status:"running"}),(s=f.schemaChange)!=null&&s.schemaId?($("Step 3/4: Schema change detected, waiting for validation..."),await Xt(u,o,f.schemaChange.schemaId)):$("Step 3/4: No schema change, skipping validation wait"),r("wait-schema",{status:"done"}),$("Step 3/4: Schema validation complete"),r("finalize",{status:"running"}),$("Step 4/4: Finalizing deployment..."),await Kt(u,o),r("finalize",{status:"done"}),$("Step 4/4: Deployment finalized"),$("=== Convex deployment finished ==="),!0}catch(a){const c=a instanceof Error?a.message:String(a);$(`=== Convex deployment FAILED: ${c} ===`);const u=n.find(d=>d.status==="running"||d.status==="waiting");return u&&r(u.id,{status:"error",error:c}),!1}}function R(e,t){const o=new Date().toISOString();console.log(`[deploy-supabase ${o}] ${e}`)}const Qt=`
-- Create tables if they don't exist yet
CREATE TABLE IF NOT EXISTS videos (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  short_code text UNIQUE NOT NULL,
  title text NOT NULL,
  description text,
  storage_url text NOT NULL,
  view_count integer DEFAULT 0,
  duration_ms integer,
  capture_mode text NOT NULL,
  created_at timestamptz DEFAULT now(),
  is_protected boolean DEFAULT false,
  password_salt text
);

CREATE TABLE IF NOT EXISTS reactions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  video_short_code text NOT NULL,
  emoji text NOT NULL,
  timestamp real NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Migrate videos table from older schemas
DO $$ BEGIN
  -- short_code (was missing in early schemas)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='short_code') THEN
    ALTER TABLE videos ADD COLUMN short_code text UNIQUE;
    UPDATE videos SET short_code = substr(gen_random_uuid()::text, 1, 8) WHERE short_code IS NULL;
    ALTER TABLE videos ALTER COLUMN short_code SET NOT NULL;
  END IF;
  -- storage_url (older schema used storage_path)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='storage_url') THEN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='storage_path') THEN
      ALTER TABLE videos RENAME COLUMN storage_path TO storage_url;
    ELSE
      ALTER TABLE videos ADD COLUMN storage_url text NOT NULL DEFAULT '';
    END IF;
  END IF;
  -- duration_ms
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='duration_ms') THEN
    ALTER TABLE videos ADD COLUMN duration_ms integer;
  END IF;
  -- view_count
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='view_count') THEN
    ALTER TABLE videos ADD COLUMN view_count integer DEFAULT 0;
  END IF;
  -- capture_mode
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='capture_mode') THEN
    ALTER TABLE videos ADD COLUMN capture_mode text NOT NULL DEFAULT 'screen';
  END IF;
  -- is_protected
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='is_protected') THEN
    ALTER TABLE videos ADD COLUMN is_protected boolean DEFAULT false;
  END IF;
  -- password_salt
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='videos' AND column_name='password_salt') THEN
    ALTER TABLE videos ADD COLUMN password_salt text;
  END IF;
END $$;

-- Migrate reactions table from older schemas
DO $$ BEGIN
  -- video_short_code (older schema used video_id uuid)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reactions' AND column_name='video_short_code') THEN
    ALTER TABLE reactions ADD COLUMN video_short_code text NOT NULL DEFAULT '';
    -- Backfill from video_id if the old column exists
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reactions' AND column_name='video_id') THEN
      UPDATE reactions r SET video_short_code = v.short_code
        FROM videos v WHERE v.id = r.video_id;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_videos_short_code ON videos(short_code);
CREATE INDEX IF NOT EXISTS idx_videos_created_at ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reactions_video ON reactions(video_short_code);

-- RLS policies
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE reactions ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'videos' AND policyname = 'Allow service role full access on videos') THEN
    CREATE POLICY "Allow service role full access on videos" ON videos FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'reactions' AND policyname = 'Allow service role full access on reactions') THEN
    CREATE POLICY "Allow service role full access on reactions" ON reactions FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;
`.trim(),Zt=`
CREATE OR REPLACE FUNCTION increment_view_count(p_short_code text)
RETURNS void AS $$
BEGIN
  UPDATE videos SET view_count = view_count + 1 WHERE short_code = p_short_code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
`.trim(),eo=`
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const url = new URL(req.url);
  const segments = url.pathname.split("/");
  const fnIdx = segments.indexOf("openloom");
  const subPath = "/" + segments.slice(fnIdx + 1).join("/");

  try {
    // GET /v?code=xxx -- video metadata
    if (subPath === "/v" && req.method === "GET") {
      const code = url.searchParams.get("code");
      if (!code) {
        return new Response(JSON.stringify({ error: "code is required" }), {
          status: 400,
          headers: corsHeaders,
        });
      }
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("short_code", code)
        .single();
      if (error || !data) {
        return new Response(JSON.stringify({ error: "Video not found" }), {
          status: 404,
          headers: corsHeaders,
        });
      }
      return new Response(JSON.stringify(data), { headers: corsHeaders });
    }

    // POST /view -- increment view count
    if (subPath === "/view" && req.method === "POST") {
      const body = await req.json();
      const code = body.code;
      if (!code) {
        return new Response(JSON.stringify({ error: "code is required" }), {
          status: 400,
          headers: corsHeaders,
        });
      }
      await supabase.rpc("increment_view_count", { p_short_code: code });
      return new Response(JSON.stringify({ ok: true }), { headers: corsHeaders });
    }

    // GET /reactions?code=xxx -- list reactions
    if (subPath === "/reactions" && req.method === "GET") {
      const code = url.searchParams.get("code");
      if (!code) {
        return new Response(JSON.stringify({ error: "code is required" }), {
          status: 400,
          headers: corsHeaders,
        });
      }
      const { data } = await supabase
        .from("reactions")
        .select("*")
        .eq("video_short_code", code);
      return new Response(JSON.stringify(data || []), { headers: corsHeaders });
    }

    // POST /reactions/add -- add reaction
    if (subPath === "/reactions/add" && req.method === "POST") {
      const body = await req.json();
      const { code, emoji, timestamp } = body;
      if (!code || !emoji || typeof timestamp !== "number") {
        return new Response(
          JSON.stringify({ error: "code, emoji, and timestamp are required" }),
          { status: 400, headers: corsHeaders }
        );
      }
      await supabase.from("reactions").insert({
        video_short_code: code,
        emoji,
        timestamp,
        created_at: new Date().toISOString(),
      });
      return new Response(JSON.stringify({ ok: true }), {
        status: 201,
        headers: corsHeaders,
      });
    }

    return new Response(JSON.stringify({ error: "Not found" }), {
      status: 404,
      headers: corsHeaders,
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: corsHeaders,
    });
  }
});
`.trim();async function to(e,t){R("Setting up database tables...");const o=await fetch(`https://api.supabase.com/v1/projects/${e}/database/query`,{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json"},body:JSON.stringify({query:Qt})});if(!o.ok){const r=await o.text();throw new Error(`Database setup failed: ${o.status} ${r}`)}const n=await fetch(`https://api.supabase.com/v1/projects/${e}/database/query`,{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json"},body:JSON.stringify({query:Zt})});if(!n.ok){const r=await n.text();throw new Error(`RPC function setup failed: ${n.status} ${r}`)}R("Database tables and RPC function created successfully")}async function oo(e,t){R("Setting up storage bucket...");const o=e.replace(/\/+$/,""),n=await fetch(`${o}/storage/v1/bucket`,{method:"POST",headers:{Authorization:`Bearer ${t}`,apikey:t,"Content-Type":"application/json"},body:JSON.stringify({id:"videos",name:"videos",public:!0})});if(!n.ok){const r=await n.text();if(n.status===409||r.includes("already exists")){R("Storage bucket already exists, ensuring it is public...");const s=await fetch(`${o}/storage/v1/bucket/videos`,{method:"PUT",headers:{Authorization:`Bearer ${t}`,apikey:t,"Content-Type":"application/json"},body:JSON.stringify({public:!0})});if(!s.ok){const a=await s.text();R(`Warning: could not update bucket to public: ${s.status} ${a}`)}return}throw new Error(`Storage bucket creation failed: ${n.status} ${r}`)}R("Storage bucket created successfully")}async function no(e,t){R("Deploying edge function via Management API...");const o=JSON.stringify({entrypoint_path:"index.ts",name:"openloom",verify_jwt:!1}),n=`----OpenLoomBoundary${Date.now()}`,r=new TextEncoder().encode(eo),s=[],a=f=>new TextEncoder().encode(f);s.push(a(`--${n}\r
`)),s.push(a(`Content-Disposition: form-data; name="metadata"\r
`)),s.push(a(`Content-Type: application/json\r
\r
`)),s.push(a(o)),s.push(a(`\r
`)),s.push(a(`--${n}\r
`)),s.push(a(`Content-Disposition: form-data; name="file"; filename="index.ts"\r
`)),s.push(a(`Content-Type: application/typescript\r
\r
`)),s.push(r),s.push(a(`\r
`)),s.push(a(`--${n}--\r
`));const c=s.reduce((f,g)=>f+g.byteLength,0),u=new Uint8Array(c);let d=0;for(const f of s)u.set(f,d),d+=f.byteLength;const i=await fetch(`https://api.supabase.com/v1/projects/${e}/functions/deploy?slug=openloom`,{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":`multipart/form-data; boundary=${n}`},body:u.buffer});if(!i.ok){const f=await i.text();throw new Error(`Edge Function deployment failed (Management API): ${i.status} ${f}`)}R("Edge function deployed successfully via Management API")}async function ro(e,t){const o=e.supabaseProjectRef,n=e.supabaseAccessToken,r=e.supabaseProjectUrl,s=e.supabaseServiceRoleKey;if(!o||!n||!r||!s)return t([{id:"validate",label:"Validating settings...",status:"error",error:"Missing required Supabase settings (project ref, access token, project URL, or service role key)."}]),!1;const a=[{id:"setup-database",label:"Creating tables & RLS policies...",status:"pending"},{id:"setup-storage",label:"Creating storage bucket...",status:"pending"},{id:"deploy-function",label:"Deploying Edge Function...",status:"pending"}];function c(u,d){const i=a.find(f=>f.id===u);i&&Object.assign(i,d),t([...a])}R("=== Starting Supabase deployment ==="),R(`Project ref: ${o}, URL: ${r}`);try{return c("setup-database",{status:"running"}),R("Step 1/3: Setting up database tables and RLS..."),await to(o,n),c("setup-database",{status:"done"}),R("Step 1/3: Database setup complete"),c("setup-storage",{status:"running"}),R("Step 2/3: Setting up storage bucket..."),await oo(r,s),c("setup-storage",{status:"done"}),R("Step 2/3: Storage setup complete"),c("deploy-function",{status:"running"}),R("Step 3/3: Deploying Edge Function..."),await no(o,n),c("deploy-function",{status:"done"}),R("Step 3/3: Edge Function deployed"),R("=== Supabase deployment finished ==="),!0}catch(u){const d=u instanceof Error?u.message:String(u);R(`=== Supabase deployment FAILED: ${d} ===`);const i=a.find(f=>f.status==="running"||f.status==="waiting");return i&&c(i.id,{status:"error",error:d}),!1}}let V={phase:"idle",elapsed:0,blobId:null,error:null,shareURL:null,uploadProgress:0},_={};chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});const Ae="openloom-keepalive";function Ce(){chrome.alarms.create(Ae,{periodInMinutes:.4})}function ie(){chrome.alarms.clear(Ae)}chrome.alarms.onAlarm.addListener(e=>{e.name});function Je(e){const t={type:"STATE_UPDATE",state:{...V},settings:e};chrome.runtime.sendMessage(t).catch(()=>{})}function U(e){Object.assign(V,e),Je()}async function ee(){return _=(await chrome.storage.local.get("settings")).settings||{},await nt(_),_}async function ye(e){return _={..._,...e},await chrome.storage.local.set({settings:_}),_}async function so(){_={},await chrome.storage.local.remove("settings")}let re=null;async function ao(){if(!((await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length>0)){if(re){await re;return}re=chrome.offscreen.createDocument({url:"offscreen/offscreen.html",reasons:[chrome.offscreen.Reason.DISPLAY_MEDIA,chrome.offscreen.Reason.USER_MEDIA],justification:"Screen recording with camera PiP and microphone audio"}),await re,re=null}}async function io(){(await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length>0&&await chrome.offscreen.closeDocument()}chrome.runtime.onMessage.addListener((e,t,o)=>(co(e).then(n=>o(n)).catch(n=>{console.error("[sw] Message handler error:",n),o({error:n instanceof Error?n.message:String(n)})}),!0));async function co(e){switch(e.type){case"GET_SETTINGS":return ee();case"SAVE_SETTINGS":return ye(e.settings);case"DISCONNECT":return await so(),U({phase:"idle",elapsed:0,blobId:null,error:null,shareURL:null,uploadProgress:0}),Je(_),{ok:!0};case"VALIDATE_CONNECTION":return uo(e.provider,e.credential);case"DEPLOY_BACKEND":return lo(e.provider);case"START_RECORDING":return fo(e.camera,e.mic,e.hd,e.cameraDeviceId,e.micDeviceId,e.pipConfig);case"STOP_RECORDING":return po();case"SET_MIC_MUTED":return chrome.runtime.sendMessage({type:"SET_MIC_MUTED",muted:e.muted});case"CAPTURE_STARTED":return U({phase:"recording",elapsed:0}),{ok:!0};case"ELAPSED_UPDATE":return U({elapsed:e.seconds}),{ok:!0};case"PREVIEW_FRAME":return chrome.runtime.sendMessage(e).catch(()=>{}),{ok:!0};case"RECORDING_STOPPED":return ie(),await io(),U({phase:"review",blobId:e.blobId}),{ok:!0};case"UPLOAD_RECORDING":return ho(e.title,e.password);case"LIST_VIDEOS":return go();case"DELETE_VIDEO":return mo(e.shortCode);case"GET_STATE":return{state:V,settings:_};default:return{error:"Unknown message type"}}}async function uo(e,t){await ye({provider:e});const o=await Ke(_,t);return o.ok||await ye({provider:void 0}),o}async function lo(e){Ce();try{await ee();const t=n=>{const r={type:"DEPLOY_PROGRESS",steps:n};chrome.runtime.sendMessage(r).catch(()=>{})};let o=!1;return e==="firebase"?o=await Bt(_,t):e==="convex"?o=await Yt(_,t):e==="supabase"&&(o=await ro(_,t)),{ok:o}}finally{ie()}}async function fo(e,t,o,n,r,s){try{Ce(),U({phase:"countdown",error:null}),await ao(),await new Promise(c=>setTimeout(c,200));const a=await chrome.runtime.sendMessage({type:"CAPTURE_AND_RECORD",camera:e,mic:t,hd:o,cameraDeviceId:n,micDeviceId:r,pipConfig:s});if(a&&!a.ok)throw new Error(a.error||"Failed to start recording");return{ok:!0}}catch(a){return ie(),U({phase:"idle",error:a instanceof Error?a.message:"Failed to start recording"}),{ok:!1,error:a instanceof Error?a.message:String(a)}}}async function po(){try{return await chrome.runtime.sendMessage({type:"STOP_CAPTURE"}),{ok:!0}}catch(e){return{ok:!1,error:e instanceof Error?e.message:String(e)}}}async function ho(e,t){Ce(),U({phase:"uploading",uploadProgress:0});try{await ee(),U({uploadProgress:10});const o=await it(b=>Ye(_,b));U({uploadProgress:20});const n=await rt(V.blobId);if(!n)throw new Error("Recording blob not found in storage");const r=await n.arrayBuffer();U({uploadProgress:30});const s=n.type||"video/webm",c=`videos/${o}.${s==="video/mp4"?"mp4":"webm"}`,u=await Qe(_,c,r,s);if(!u.ok)throw new Error(u.error||"Upload failed");U({uploadProgress:70});const d=_.provider||"firebase";let i=u.url;d==="convex"&&_.convexHttpActionsUrl&&(i=`${_.convexHttpActionsUrl}/video?code=${o}`);let f=i,g,h;if(t){const{encrypted:b,salt:y}=await lt(i,t);f=b,g=!0,h=y}const v={short_code:o,title:e||"Untitled Recording",description:null,storage_url:f,view_count:0,duration_ms:V.elapsed*1e3,capture_mode:"screen",created_at:new Date().toISOString()};u.storageId&&(v.storage_id=u.storageId),g&&(v.is_protected=!0,v.password_salt=h??null),await Ze(_,"videos",o,v),U({uploadProgress:100});const w=et(_,o);return U({shareURL:w}),V.blobId&&st(V.blobId).catch(()=>{}),{ok:!0,shareURL:w}}catch(o){return U({phase:"review",error:o instanceof Error?o.message:"Upload failed",uploadProgress:0}),{ok:!1,error:o instanceof Error?o.message:String(o)}}finally{ie()}}async function go(){await ee();const e=await tt(_,"videos","created_at","desc");return e.ok?{videos:e.data||[]}:{error:e.error}}async function mo(e){await ee();const t=_.provider||"firebase";return(t==="firebase"||t==="supabase")&&(await De(_,`videos/${e}.webm`),await De(_,`videos/${e}.mp4`)),ot(_,"videos",e)}chrome.storage.session.get("appState").then(e=>{e.appState&&(V=e.appState)});setInterval(()=>{chrome.storage.session.set({appState:V}).catch(()=>{})},5e3);ee();
